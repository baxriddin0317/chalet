export const menuItems = [
  {
    name: "home",
    href: "#",
    items: [
      {
        name: "home1",
        href: "#",
      },
      {
        name: "home2",
        href: "#",
      },
      {
        name: "home3",
        href: "#",
      },
      {
        name: "home4",
        href: "#",
      },
    ]
  },
  {
    name: "pages",
    href: "#",
    items: [
      {
        name: "pages1",
        href: "#",
      },
      {
        name: "pages2",
        href: "#",
      },
      {
        name: "pages3",
        href: "#",
      },
      {
        name: "pages4",
        href: "#",
      },
    ]
  },
  {
    name: "blog",
    href: "#",
    items: [
      {
        name: "blog1",
        href: "#",
      },
      {
        name: "blog2",
        href: "#",
      },
      {
        name: "blog3",
        href: "#",
      },
      {
        name: "blog4",
        href: "#",
      },
    ]
  },
  {
    name: "features",
    href: "#",
    items: [
      {
        name: "features1",
        href: "#",
      },
      {
        name: "features2",
        href: "#",
      },
      {
        name: "features3",
        href: "#",
      },
      {
        name: "features4",
        href: "#",
      },
    ]
  },
]